#include <iostream>

using namespace std;

#define MAX 5

struct node
{

     int data;
     node *link;
};

class stacks
{

   int top;
   node *start;
   node *linkedList;

   public:
       // Constructor
       stacks(){
          top = 0;
          start = NULL;
       }

       // PUSH method

       void push(int data)
       {

            if( nodeNumber(start) == MAX ){
                 cout << "\nStack OverFlow!!!" << endl;
            }else if( isEmpty() ){

                linkedList = newNode();
                linkedList->data = data;
                start = linkedList;
                top++;

                cout <<endl<< data << " PUSHED in the stack!" << endl;

            }else{

               node *temp = newNode();
               temp->data = data;
               linkedList = start;

               while( linkedList != NULL ){

                   if( linkedList->link == NULL ){

                     linkedList->link = temp;
                     break;
                   }

                   linkedList = linkedList->link;
               }

               top++;
               cout << endl << data << " PUSHED in the stack!" << endl;

            }

       }

       // pop method

       void pop(){

            if( top == 0 ){

                 cout << "\nStack UnderFlow!" << endl;
            }else if(top == 1){

                 cout << "\nPOPED from the stack!" << endl;
                 start = NULL;
                 top--;
            }else {

               node *temp ;
               linkedList = start;

               while( linkedList != NULL  ){

                   if( linkedList->link->link == NULL ) break;
                   linkedList = linkedList->link;
               }

               linkedList->link = NULL;
               cout << "\nPOPED from the stack!" << endl;
               top--;

            }

       }

       //Display node data

       void display(){

            linkedList = start;

            if( linkedList == NULL ){
                cout << "\nStack is Empty!" << endl;
            }else{


                  while( linkedList != NULL ){

                 cout << linkedList->data << " ";
                 linkedList = linkedList->link;
                }
            }
       }

       // counting node number

    int nodeNumber(node *start){

        int counter = 0;

         while( start != NULL ){
             counter++;
             start = start->link;
         }
        return counter;
    }

    // checking if the stack is empty??

    bool isEmpty(){

       if( top == 0 )
        return true;
       else
       return false;
    }

   private:

       // return new node address

    node* newNode(){

         node *temp = new node;
         temp->data = NULL;
         temp->link = NULL;
         return temp;
    }


};



int main()
{
    stacks *st = new stacks;

    int choice;
    bool flag = true;
    int number;

    while( flag ){

        cout << "\n1. PUSH." << endl;
        cout << "2. POP."  << endl;
        cout << "3. Display." << endl;

        cout << endl << "\nEnter choice: ";
        cin >> choice;

        switch( choice ){

        case 1:

             cout << "\nEnter number: ";
             cin >> number;
             st->push(number);

            break;

        case 2:

              st->pop();

            break;

        case 3:

            st->display();

            break;

        case 4:
              flag = false;
            break;

        }

    }


    return 0;
}
