#include <iostream>

using namespace std;

void printArray(int a[], int n){

     for( int i = 0; i < n; i++){
        cout << a[i] << " " ;
     }

     cout << endl;
}

int main()
{
    int array_size = 5;
    int arr[100] = {5,7,13,2,9,8};
    int temp , j, min, n = 0;

    printArray(arr,array_size);

    for( int i = 0; i <= array_size; i++  ){

        min = arr[i];

         for (  j = i ; j <= array_size; j++ ){
            if( min > arr[j] ){
               min = arr[j];
               n = j;
            }
         }

        temp = arr[i];
        arr[i] = min;
        arr[n] = temp;

    }

    printArray(arr,array_size);

    return 0;
}
